﻿
//angular filter logic for paging
app.filter('startFrom', function () {
    return function (data, start) {
        if (!data || !data.length) { return; }
        return data.slice(start);
    }
});

//angular filter logic for ddl filter
app.filter('pickGenre', function () {
    return function (movies, genreObj) {
        var filtered = [];
        if (typeof genreObj != 'undefined' && genreObj != null && movies != undefined && movies.length != 0) {

            for (var i = 0; i < movies.length; i++) {
                if (movies[i].genre_ids.length > 0
                        && movies[i].genre_ids.indexOf(genreObj.id) != -1) {
                    filtered.push(movies[i]);
                }
            }
            //$scope.filteredRecordCount =  filtered.length;
            return filtered;
        }
        return movies;
    };
});