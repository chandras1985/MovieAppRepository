﻿
var app = angular.module('movieApp', ['ui.bootstrap','ngRoute']);

//routing logic
app.config(function ($routeProvider) {

    var viewBase = '/app/MoviesApp/Views/';

    $routeProvider
        .when('/', { controller: 'movieController', templateUrl: viewBase + 'recentMoviesList.html'})
        .otherwise({ redirectTo: '/' });

});