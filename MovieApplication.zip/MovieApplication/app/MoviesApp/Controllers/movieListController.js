﻿
//controller logic
app.controller('movieController', function ($scope, $http, $window) {

    $scope.pageSize = 10;
    $scope.currentPage = 1;
    $scope.pathToFetchPoster = 'https://image.tmdb.org/t/p/w185_and_h278_bestv2/';
    //The get image api returns image name. Since there was a need to get the image file, used the above path to fetch the image file.

    //To get the list of movies
    $http
       .get('https://api.themoviedb.org/3/movie/now_playing?api_key=f956e6c5447403447ae6fa5bd2ccfcef&language=en-US')
       .success(function (response) { $scope.movies = response.results; })
       .error(function () { $window.alert('oops...something went wrong'); });

    //To get hte list of genres
    $http
        .get('https://api.themoviedb.org/3/genre/movie/list?api_key=f956e6c5447403447ae6fa5bd2ccfcef&language=en-US')
        .success(function (response) { $scope.genres = response.genres })
        .error(function () { $window.alert('oops...something went wrong') });
});